package com.abhilash.smartcampusmqttlib.Interfaces;

/**
 * Created by shashankshekhar on 01/06/16.
 */
public interface ServiceStatusCallback {
    void serviceConnected ();
    void serviceDisconnected();
}
