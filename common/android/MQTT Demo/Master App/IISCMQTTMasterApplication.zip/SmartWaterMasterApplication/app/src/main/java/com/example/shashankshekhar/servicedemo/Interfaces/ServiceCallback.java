package com.example.shashankshekhar.servicedemo.Interfaces;

/**
 * Created by shashankshekhar on 30/03/16.
 * not being used remove
 */
//public interface ServiceCallback {
//    void messageReceivedFromService(int number);
//    void serviceDisconnected ();
//    void serviceConnected ();
//}
/*
remove this interfaces all of these callbacks will now come from Service callback in the library. even when service
connects and disconnects
 */