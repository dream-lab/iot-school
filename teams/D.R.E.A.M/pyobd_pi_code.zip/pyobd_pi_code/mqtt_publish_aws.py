# -*- coding: utf-8 -*-

import paho.mqtt.client as paho
import time
import random
def on_connect(client, userdata, flags, rc):
    print("CONNACK received with code %d." % (rc))

#Topic = ["client1/data"]
# Topic=["iisc/smartx/crowd/network/mqttTest"]

topic="pi/speed"
dataset=["1","2","3","4"]

import uuid
client = paho.Client(client_id=str(uuid.uuid4()))
client.on_connect = on_connect


client.username_pw_set("smartcar", "smartcar")
client.connect("52.200.58.205",1883)

import math
#client.username_pw_set("admin", "scdl@119")
#client.connect("smartx.cds.iisc.ac.in",1883)
client.loop_start()

from time import sleep
import csv
speed_limit=58.9
with open('log/DATA1.csv', 'rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    count=0
    for row in spamreader:
        if count==0:
            count=1
        else:
            speed = 1.60934*float(row[2])
            (rc, mid) = client.publish(topic, str(speed), 2)
            print row[2]
            if speed > speed_limit:
                print "ALERT: "+ str(speed)
            sleep(0.5)

# while True:
#     for topic in Topic:
#         # dataset = random.choice(dataset)
#         dataset=random.randint(0,9)
#
#         (rc, mid) = client.publish(topic, dataset)
#     print "working"
#     time.sleep(1)
