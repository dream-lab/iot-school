import pandas as pd
import matplotlib.pyplot as plt

df=pd.read_csv('log/DATA1.csv')

KPH_list=df["MPH"]*1.60934
print KPH_list

TIME_list=df["Time"]
print TIME_list

Time=[]
print len(TIME_list)
x_axis_dummy = []
x_axis_tick = []
count = 0

for i in TIME_list:
    if count%20 == 0:
        str_dum=str(i).split(':')
        Time.append(str_dum[0]+":"+str_dum[1])
        x_axis_tick.append(count)
    x_axis_dummy.append(count)
    count = count+1

plt.xticks(x_axis_tick, Time)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)

plt.xlabel('Time (Hours:Mins)')
plt.ylabel('Speed (KPH)')

plt.plot(x_axis_dummy,KPH_list)
plt.title('Time Series plot of Speed')
# plt.plot(dates, values)
plt.show()



RPM_list=df["RPM"]
print RPM_list

TIME_list=df["Time"]
print TIME_list

Time=[]
print len(TIME_list)
x_axis_dummy = []
x_axis_tick = []
count = 0

for i in TIME_list:
    if count%20 == 0:
        str_dum=str(i).split(':')
        Time.append(str_dum[0]+":"+str_dum[1])
        x_axis_tick.append(count)
    x_axis_dummy.append(count)
    count = count+1

plt.xticks(x_axis_tick, Time)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)

plt.xlabel('Time (Hours:Mins)')
plt.ylabel('Motor RPM')

plt.plot(x_axis_dummy,RPM_list)
plt.title('Time Series plot of RPM')
# plt.plot(dates, values)
plt.show()

