import pandas as pd

logitems = ["rpm", "speed", "throttle_pos", "load", "fuel_status",
"dtc_status",
"dtc_ff",
"fuel_status",
"load",
"temp",
"short_term_fuel_trim_1",
"long_term_fuel_trim_1",
"short_term_fuel_trim_2",
"long_term_fuel_trim_2",
"fuel_pressure",
"manifold_pressure",
"rpm",
"speed",
"timing_advance",
"intake_air_temp",
"maf",
"throttle_pos",
"secondary_air_status",
"o2_sensor_positions",
"o211",
"o212",
"o213",
"o214",
"o221",
"o222",
"o223",
"o224",
"obd_standard",
"o2_sensor_position_b",
"aux_input",
"engine_time",
"engine_mil_time"
]

# data=pd.read_csv('log/DATA1.csv');
#
# for row in data.rows:
#    print row['Time'], row['speed']
import csv
with open('log/DATA1.csv', 'rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    count=0
    speed_alert_count=0
    for row in spamreader:
        if count==0:
            count=1
        else:
            speed = float(row[2])*1.60934
            if  speed > 58.0:
                speed_alert_count=speed_alert_count+1
                print "SPEED VIOLATION: "+ str(speed)
            # print row[2]

    print "SPEED GREATER > 60 = "+str(speed_alert_count)

