#import obd
import time
infi = 1
speed = 10
#conn = obd.OBD()
	
while infi < 10:

	#s = conn.query(obd.commands.SPEED) #Speed object
	#speed = s.value 		   #speed value extracted
	#speed = int(speed)
	
	#r = conn.query(obd.commands.RPM) #Speed object
	#rpm = r.value 		   #speed value extracted
	#rpm = int(rpm)
	
	#th = conn.query(obd.commands.THROTTLE)
	#throttle = th.value
	#throttle = int(throttle)
	
	with open("/home/pi/pi/CalculateAvgSpeed/src/org/controller/speedlimit.txt",'r') as r:
		limit = r.readline()
		r.close()
		limit = int(limit)
		 
	if speed > limit:
		with open("/home/pi/iot/alert.txt",'w') as file:
			file.write('1')
			file.close()
		print "Alert!!!!!"
	if speed < limit:
                with open("/home/pi/iot/alert.txt",'w') as file:
                        file.write('0')
                        file.close()
                print "Ok Speed!"
	
	with open("/home/pi/pi/PublishSpeed/speed.csv",'w') as f:
		speed = str(speed)
		f.write("kph,"+speed)
		f.close()

	time.sleep(1)
	infi = infi + 1
	
