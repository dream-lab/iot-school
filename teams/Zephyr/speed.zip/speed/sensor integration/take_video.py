import time
import os
infi = 1


while infi < 5:
	raspivid -o video.h264 -t 5000
	time.sleep(5)
	with open("/home/pi/iot/alert.txt",'r') as file:
		alert = file.readline()
		alert = int(alert)
	if alert == 0:
		os.system("sudo rm video.h264")	
	if alert == 1:
		os.system("cp video.h264 /home/pi/")
	infi = infi + 1
	
