package org.controller;

/**
+---------------+------+---------+
|         SenML | JSON | Type    |
+---------------+------+---------+
|     Base Name | bn   | String  |
|     Base Time | bt   | Number  |
|     Base Unit | bu   | String  |
|    Base Value | bv   | Number  |
|       Version | bver | Number  |
|          Name | n    | String  |
|          Unit | u    | String  |
|         Value | v    | Number  |
|  String Value | vs   | String  |
| Boolean Value | vb   | Boolean |
|    Data Value | vd   | String  |
|     Value Sum | s    | Number  |
|          Time | t    | Number  |
|   Update Time | ut   | Number  |
+---------------+------+---------+

Optional:
agrs[0]=absolute path of csv file
*/
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Random;
import java.util.Scanner;



import java.io.File;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.senml.data.MqttEvent;
import org.senml.data.SenML;

public class PublishTemperature {

	// Default value used if broker.properties file does not exist
	static String BrokerURL = "tcp://iotsummerschoolmqttbroker.cloudapp.net:1883";
	static String UserName = "iotsummer";
	static String Password = "iotsummer";
	static String Topic = "zephyr/speedChange";
	static String ClientId;

	public static void main(String[] args) throws Exception {

		MemoryPersistence persistence = new MemoryPersistence();
		ClientId = String.valueOf(new Random().nextInt(500000));
		try {

			initCredentials();
			String topicName = Topic;
			String content;
			int qos = 2;
			MqttConnectOptions connOpts = new MqttConnectOptions();
			connOpts.setUserName(UserName);
			connOpts.setPassword(Password.toCharArray());
			connOpts.setCleanSession(true);
			MqttClient mqttClient = new MqttClient(BrokerURL, ClientId, persistence);
			System.out.println("Connecting to broker: " + BrokerURL);
			mqttClient.connect(connOpts);
			System.out.println("Connected");			
			//content = getJSONContentFromFile(args);
			  // Reading from System.in
			System.out.println("Enter the new speed limit: ");
			Scanner reader = new Scanner(System.in);
			int n = reader.nextInt();	
			content=Integer.toString(n);				
			System.out.print("Publishing topic : " + topicName);
			// now adapt this content value in senMl format
			String cont = "";
			MqttEvent mqttsendEvent = new MqttEvent();
			SenML reading = new SenML();
			reading.setUnit("m");
			reading.setValue(Integer.parseInt(content));
			mqttsendEvent.add(reading);
			content = mqttsendEvent.getJSONReprsentation();
			MqttMessage message = new MqttMessage(content.getBytes());
			System.out.println(" To : " + BrokerURL + " : Publishing message:" + content);
			message.setQos(qos);
			mqttClient.publish(topicName, message);
			//Thread.sleep(3000);	
			System.exit(0);	

			

		} catch (MqttException me) {
			System.out.println("Reason " + me.getReasonCode());
			System.out.println("Message " + me.getMessage());
			System.out.println("Local message " + me.getLocalizedMessage());
			System.out.println("Cause " + me.getCause());
			System.out.println("Exception " + me);
			me.printStackTrace();
		}
	}

	
	


	
	public static void initCredentials() {

		String brokerConnectionFile = System.getProperty("user.dir") + "/broker.properties";

		Properties prop;
		InputStream input = null;
		try {

			prop = new Properties();
			input = new FileInputStream(brokerConnectionFile);

			prop.load(input);

			if (prop.getProperty("brokerurl") != null)
				BrokerURL = prop.getProperty("brokerurl");
			if (prop.getProperty("username") != null)
				UserName = prop.getProperty("username");
			if (prop.getProperty("password") != null)
				Password = prop.getProperty("password");

		} catch (FileNotFoundException e) {

		} catch (Exception e) {

		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return;

	}
}
