package org.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Random;

/**
+---------------+------+---------+
|         SenML | JSON | Type    |
+---------------+------+---------+
|     Base Name | bn   | String  |
|     Base Time | bt   | Number  |
|     Base Unit | bu   | String  |
|    Base Value | bv   | Number  |
|       Version | bver | Number  |
|          Name | n    | String  |
|          Unit | u    | String  |
|         Value | v    | Number  |
|  String Value | vs   | String  |
| Boolean Value | vb   | Boolean |
|    Data Value | vd   | String  |
|     Value Sum | s    | Number  |
|          Time | t    | Number  |
|   Update Time | ut   | Number  |
+---------------+------+---------+
*/

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;

public class SubscribeTemperature implements MqttCallback {

	// Default value used if broker.properties file does not exist
	static String BrokerURL = "tcp://iotsummerschoolmqttbroker.cloudapp.net:1883";
	static String UserName = "iotsummer";
	static String Password = "iotsummer";
	static String Topic = "zephyr/speed";
	static String ClientId ;

	MqttClient client;

	public SubscribeTemperature() {
	}

	public static void main(String[] args) {
		ClientId = String.valueOf(new Random().nextInt());
		new SubscribeTemperature().subscribe(args);
	}

	public void subscribe(String[] args) {

		initCredentials();
		
		try {

			String topicName = Topic;
			if (args.length > 0)
				topicName = args[0];

			MqttConnectOptions connOpts = new MqttConnectOptions();

			connOpts.setCleanSession(true);
			connOpts.setUserName(UserName);
			connOpts.setPassword(Password.toCharArray());

			client = new MqttClient(BrokerURL, ClientId);
			client.connect(connOpts);
			client.setCallback(this);
			client.subscribe(topicName);

			System.out.println("subscription topic : " + topicName);

		} catch (MqttException e) {
			e.printStackTrace();
		}
	}

	public static void initCredentials() {

		String brokerConnectionFile = System.getProperty("user.dir") + "/broker.properties";

		Properties prop;
		InputStream input = null;
		try {

			prop = new Properties();
			input = new FileInputStream(brokerConnectionFile);

			prop.load(input);

			if (prop.getProperty("brokerurl") != null)
				BrokerURL = prop.getProperty("brokerurl");
			if (prop.getProperty("username") != null)
				UserName = prop.getProperty("username");
			if (prop.getProperty("password") != null)
				Password = prop.getProperty("password");

		} catch (FileNotFoundException e) {

		} catch (Exception e) {

		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return;

	}
	

	@Override
	public void connectionLost(Throwable cause) {
		// TODO Auto-generated method stub

	}

	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		System.out.println(BrokerURL + " : " + message);
		Double average = CalculateAverage.calculateAverage(message);
		/* read the value from file the new threshold speed limit then if the speed limit is more then also publish a push message to authority */
		int speedLimit=getSpeedLimit();
		if(average>=speedLimit){						
			// trigger an alert to all concerned authorities that the average speed is very high
			SendAlert.publishResults(average);
			PublishAvgTemperature.publishResults(average);			
		
		}
		else{		
			/* also log the average speed value of the car in a file for future purpose*/
			PublishAvgTemperature.publishResults(average);	
		}
		

	

	}

	public static int getSpeedLimit(){
		Integer a=0;
			String speedLimitFile = "/home/pi/pi/CalculateAvgSpeed/src/org/controller/speedlimit.txt";
			File file = new File(speedLimitFile);
			BufferedReader reader = null;

			try {
			    reader = new BufferedReader(new FileReader(file));
			    String text = null;

			    while ((text = reader.readLine()) != null) {
				//list.add(Integer.parseInt(text));
				a=Integer.parseInt(text);
			    }
			} catch (FileNotFoundException e) {
			    e.printStackTrace();
			} catch (IOException e) {
			    e.printStackTrace();
			} finally {
			    try {
				if (reader != null) {
				    reader.close();
				}
			    } catch (IOException e) {
			    }
			}

			//print out the list
			System.out.println("Speed limit is:"+a);
			return a; 


	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		// TODO Auto-generated method stub

	}

}
