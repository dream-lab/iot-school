
<?php
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "smartTransport";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
	$sql = "SELECT * FROM speedData";
	$result = $conn->query($sql);
     $data = array(array("timestamp", "speed"));
	//echo $result->num_rows;
     if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()){
			//echo $res;"
				echo $row['timestamp']."->".$row['speed']." kmph";
				echo "<br>";
		     $data[] = array($row['timestamp'], $row['speed']);
	     }
	}
	else{
		
		echo "0 results";

		}

    
?>


